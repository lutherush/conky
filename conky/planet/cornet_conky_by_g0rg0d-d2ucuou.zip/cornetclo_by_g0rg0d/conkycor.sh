#!/bin/bash
sleep 20
conky -c ~/.conkyclo &
sleep 10
conky -c ~/.conkyrcmx
exit 0
