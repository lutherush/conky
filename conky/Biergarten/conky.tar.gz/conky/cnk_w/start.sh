#!/bin/bash
#sleep 18&&
conky -c /home/narf/02Sys/cnk_w/conky1&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_w/conky2&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_w/conky3&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_w/conky5&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_w/conky4
