#!/bin/bash
#sleep 18&&
conky -c /home/narf/02Sys/cnk_o/conky1&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_o/conky2&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_o/conky3&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_o/conkyxx&&
sleep 1&&
conky -c /home/narf/02Sys/cnk_o/conky4
